package com.ehsan.icooler.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ehsan.icooler.MainViewModel
import com.ehsan.icooler.ui.theme.*

@Composable
fun LogsScreen(viewModel: MainViewModel, navController: NavController) {
    val logger = viewModel.logger
    val records = remember { derivedStateOf { logger.getRecent(100) } }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("📋 SESSION LOGS", fontSize = 20.sp, color = Color.White, modifier = Modifier.padding(start = 8.dp))
            Spacer(modifier = Modifier.weight(1f))
            Text("Records: ${logger.size()}", color = TextSecondary, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(16.dp))
        GlassCard(modifier = Modifier.weight(1f)) {
            LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                item {
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Time", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1.5f))
                        Text("Temp", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text("FPS", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                        Text("Fan%", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                        Text("Alert", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(0.8f))
                    }
                    HorizontalDivider(color = CardBorder)
                }
                items(records.value) { record ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(record.timestamp.substring(11, 19), color = TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.5f))
                        Text("${record.tempC}°C", color = if (record.tempC > 50) AccentRed else if (record.tempC > 45) AccentOrange else TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text(record.fps.toString(), color = if (record.fps < 40) AccentRed else TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(0.8f))
                        Text("${record.fanPercent}%", color = if (record.fanPercent > 80) AccentGreen else TextSecondary, fontSize = 11.sp, modifier = Modifier.weight(0.8f))
                        Text(when (record.alert) { 2 -> "●"; 1 -> "○"; else -> "-" },
                            color = when (record.alert) { 2 -> AccentRed; 1 -> AccentOrange; else -> TextSecondary },
                            fontSize = 14.sp, modifier = Modifier.weight(0.8f))
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { viewModel.exportCsv() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)) { Text("EXPORT CSV") }
            Button(onClick = { viewModel.clearLogs() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AccentRed)) { Text("CLEAR") }
        }
    }
}