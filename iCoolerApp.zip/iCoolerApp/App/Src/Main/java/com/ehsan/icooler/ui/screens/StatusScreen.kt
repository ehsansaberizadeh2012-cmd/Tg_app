package com.ehsan.icooler.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ehsan.icooler.BluetoothManager
import com.ehsan.icooler.MainViewModel
import com.ehsan.icooler.ui.theme.*

@Composable
fun StatusScreen(viewModel: MainViewModel, navController: NavController) {
    val temp by viewModel.currentTemp.collectAsState()
    val fps by viewModel.currentFps.collectAsState()
    val fanPercent by viewModel.fanPercent.collectAsState()
    val fanRpm by viewModel.fanRpm.collectAsState()
    val fanActive by viewModel.fanActive.collectAsState()
    val trend by viewModel.trendValue.collectAsState()
    val predicted by viewModel.predictedTemp.collectAsState()
    val status by viewModel.thermalStatus.collectAsState()
    val connected by viewModel.bluetoothManager.connectionState.collectAsState()
    val confidence by viewModel.aiConfidence.collectAsState()
    val accentColor = when { temp > 50 -> AccentRed; temp > 45 -> AccentOrange; else -> AccentBlue }

    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(color = accentColor.copy(alpha = 0.08f), radius = size.minDimension * 0.5f, center = Offset(size.width * 0.3f, size.height * 0.2f))
            drawCircle(color = Color.Cyan.copy(alpha = 0.06f), radius = size.minDimension * 0.4f, center = Offset(size.width * 0.8f, size.height * 0.9f))
        }
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
            DynamicIsland("iCooler Pro v26",
                when (connected) { BluetoothManager.ConnectionState.CONNECTED -> "Connected to FangamingV1"
                    BluetoothManager.ConnectionState.CONNECTING -> "Connecting..."
                    else -> "Disconnected" },
                when (connected) { BluetoothManager.ConnectionState.CONNECTED -> AccentGreen
                    BluetoothManager.ConnectionState.CONNECTING -> AccentOrange
                    else -> Color.Gray },
                Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(24.dp))
            Box(modifier = Modifier.fillMaxWidth().aspectRatio(1f)) {
                TemperatureGauge(temp, accentColor, Modifier.fillMaxSize())
                Column(modifier = Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${"%.1f".format(temp)}°C", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(status, fontSize = 18.sp, color = accentColor)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                GlassCard(Modifier.weight(1f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("FPS", fontSize = 14.sp, color = TextSecondary)
                        Text(fps.toString(), fontSize = 36.sp, fontWeight = FontWeight.Bold, color = if (fanActive) FpsActive else Color.White)
                        LinearProgressIndicator(progress = { fps / 120f }, color = FpsActive, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)))
                    }
                }
                GlassCard(Modifier.weight(1f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("FAN", fontSize = 14.sp, color = TextSecondary)
                        Text("$fanPercent%", fontSize = 36.sp, fontWeight = FontWeight.Bold, color = accentColor)
                        Text("$fanRpm RPM", fontSize = 14.sp, color = TextSecondary)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                GlassCard(Modifier.weight(1f)) {
                    Text("AI TREND", fontSize = 14.sp, color = TextSecondary)
                    Text("${"%+.2f".format(trend)}°C/s", fontSize = 20.sp, color = if (trend > 0.2f) AccentOrange else AccentGreen)
                    Text("Conf: ${(confidence * 100).toInt()}%", fontSize = 12.sp, color = TextSecondary)
                }
                GlassCard(Modifier.weight(1f)) {
                    Text("PREDICTION", fontSize = 14.sp, color = TextSecondary)
                    Text("${"%.1f".format(predicted)}°C", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = accentColor)
                    Text("in 10s", fontSize = 12.sp, color = TextSecondary)
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().height(50.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TabButton("SCIENCE", false) { navController.navigate("science") }
                TabButton("HARDWARE", false) { navController.navigate("hardware") }
                TabButton("LOGS", false) { navController.navigate("logs") }
            }
        }
    }
}

@Composable
fun DynamicIsland(title: String, subtitle: String, statusColor: Color, modifier: Modifier = Modifier) {
    Box(modifier = modifier.height(70.dp).clip(RoundedCornerShape(35.dp)).background(Color.Black.copy(alpha = 0.85f)).padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(if (subtitle.contains("Connected")) Icons.Default.BluetoothConnected else Icons.Default.Bluetooth, null, tint = statusColor, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = statusColor, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun TemperatureGauge(temp: Float, accentColor: Color, modifier: Modifier = Modifier) {
    val animatedAngle by animateFloatAsState(targetValue = 180 + ((temp - 20) / 60) * 180,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessVeryLow), label = "gauge_angle")
    Canvas(modifier = modifier) {
        val radius = size.minDimension / 2.5f; val center = Offset(size.width / 2, size.height / 2)
        drawArc(Color(0x33FFFFFF), 180f, 180f, false, style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round),
            topLeft = Offset(center.x - radius, center.y - radius), size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2))
        drawArc(accentColor, 180f, animatedAngle - 180, false, style = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round),
            topLeft = Offset(center.x - radius, center.y - radius), size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2))
        val needleLength = radius * 0.85f; val needleAngle = (animatedAngle - 90) * (Math.PI / 180)
        val needleX = center.x + needleLength * kotlin.math.cos(needleAngle).toFloat()
        val needleY = center.y + needleLength * kotlin.math.sin(needleAngle).toFloat()
        drawLine(Color.White.copy(alpha = 0.9f), center, Offset(needleX, needleY), strokeWidth = 4.dp.toPx())
        drawCircle(Color.White, radius = 8.dp.toPx(), center = center)
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier, shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardGlass),
        border = BorderStroke(1.dp, CardBorder)) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, content = content)
    }
}

@Composable
fun TabButton(text: String, selected: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = if (selected) AccentBlue else Color(0xFF333344), contentColor = Color.White),
        shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) { Text(text) }
}