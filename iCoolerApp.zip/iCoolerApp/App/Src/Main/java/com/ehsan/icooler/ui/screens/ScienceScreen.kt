package com.ehsan.icooler.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ehsan.icooler.MainViewModel
import com.ehsan.icooler.ui.theme.*
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet

@Composable
fun ScienceScreen(viewModel: MainViewModel, navController: NavController) {
    val tempHistory by viewModel.tempHistory.collectAsState()
    val trend by viewModel.trendValue.collectAsState()
    val predicted by viewModel.predictedTemp.collectAsState()
    val confidence by viewModel.aiConfidence.collectAsState()
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("📊 THERMAL SCIENCE LAB", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(start = 8.dp))
        }
        Spacer(modifier = Modifier.height(16.dp))
        GlassCard(modifier = Modifier.weight(1f)) {
            Text("Temperature History (last 120 samples)", fontSize = 16.sp, color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            if (tempHistory.isNotEmpty()) {
                androidx.compose.ui.viewinterop.AndroidView(modifier = Modifier.fillMaxWidth().height(200.dp),
                    factory = { ctx ->
                        LineChart(ctx).apply {
                            description.isEnabled = false; setTouchEnabled(true); isDragEnabled = true; setScaleEnabled(true)
                            xAxis.position = XAxis.XAxisPosition.BOTTOM; xAxis.textColor = android.graphics.Color.WHITE
                            axisLeft.textColor = android.graphics.Color.WHITE; axisRight.isEnabled = false; legend.isEnabled = false
                            val entries = tempHistory.mapIndexed { index, value -> Entry(index.toFloat(), value) }
                            val dataSet = LineDataSet(entries, "Temperature").apply {
                                color = android.graphics.Color.parseColor("#00B0FF")
                                valueTextColor = android.graphics.Color.WHITE; lineWidth = 2f; circleRadius = 3f
                                setDrawCircleHole(false); setDrawCircles(false); mode = LineDataSet.Mode.CUBIC_BEZIER
                                setDrawFilled(true); fillColor = android.graphics.Color.parseColor("#3300B0FF"); fillAlpha = 30
                            }
                            data = LineData(dataSet); invalidate()
                        }
                    }
                )
            } else Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Collecting data...", color = TextSecondary) }
        }
        Spacer(modifier = Modifier.height(16.dp))
        GlassCard(modifier = Modifier.wrapContentHeight()) {
            Text("🧠 AI Thermal Analysis", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(8.dp))
            Text("• Trend: ${"%+.2f".format(trend)}°C/s\n• Prediction (10s): ${"%.1f".format(predicted)}°C\n• Confidence: ${(confidence * 100).toInt()}%\n• Status: ${viewModel.thermalStatus.collectAsState().value}", fontSize = 14.sp, color = TextSecondary)
        }
        Spacer(modifier = Modifier.height(16.dp))
        GlassCard(modifier = Modifier.wrapContentHeight()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = AccentBlue); Spacer(modifier = Modifier.width(8.dp))
                Text("Algorithm Specification", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("• EMA α = 0.35, β = 0.15\n• Rate of change: numerical derivative\n• Prediction: linear extrapolation\n• PWM: PID-inspired (error + derivative + future)\n• Non-blocking Bluetooth with exponential backoff", fontSize = 12.sp, color = TextSecondary)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { viewModel.exportCsv() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)) { Text("📥 CSV") }
            Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(viewModel.getGoogleSheetsLink()))) },
                modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)) { Text("📊 Sheets") }
        }
        Spacer(modifier = Modifier.height(8.dp))
    }
}