package com.ehsan.icooler

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class MainViewModel(private val context: Context) : ViewModel() {
    val bluetoothManager = BluetoothManager(context, viewModelScope)
    private val fpsMonitor = FPSMonitor()
    private val predictor = ThermalPredictor()
    val logger = DataLogger(context)

    private val _currentTemp = MutableStateFlow(32.0f)
    val currentTemp: StateFlow<Float> = _currentTemp.asStateFlow()
    private val _currentFps = MutableStateFlow(60)
    val currentFps: StateFlow<Int> = _currentFps.asStateFlow()
    private val _fanPercent = MutableStateFlow(0)
    val fanPercent: StateFlow<Int> = _fanPercent.asStateFlow()
    private val _fanRpm = MutableStateFlow(0)
    val fanRpm: StateFlow<Int> = _fanRpm.asStateFlow()
    private val _fanActive = MutableStateFlow(false)
    val fanActive: StateFlow<Boolean> = _fanActive.asStateFlow()
    private val _profile = MutableStateFlow("AI")
    val profile: StateFlow<String> = _profile.asStateFlow()
    private val _trendValue = MutableStateFlow(0.0f)
    val trendValue: StateFlow<Float> = _trendValue.asStateFlow()
    private val _predictedTemp = MutableStateFlow(32.0f)
    val predictedTemp: StateFlow<Float> = _predictedTemp.asStateFlow()
    private val _thermalStatus = MutableStateFlow("Stable")
    val thermalStatus: StateFlow<String> = _thermalStatus.asStateFlow()
    private val _tempHistory = MutableStateFlow<List<Float>>(emptyList())
    val tempHistory: StateFlow<List<Float>> = _tempHistory.asStateFlow()
    private val _aiConfidence = MutableStateFlow(0.0f)
    val aiConfidence: StateFlow<Float> = _aiConfidence.asStateFlow()
    private val _manualPwm = MutableStateFlow(0)
    val manualPwm: StateFlow<Int> = _manualPwm.asStateFlow()
    private val _snackbarMessage = MutableSharedFlow<String>()
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    private var backgroundJob: Job? = null

    init {
        startBackgroundLoop()
    }

    private fun startBackgroundLoop() {
        backgroundJob = viewModelScope.launch {
            while (isActive) {
                try {
                    val temp = simulateTemperature()
                    _currentTemp.value = temp
                    val prediction = predictor.update(temp)
                    _trendValue.value = prediction.trend
                    _predictedTemp.value = prediction.prediction
                    _thermalStatus.value = prediction.status
                    _aiConfidence.value = prediction.confidence
                    _currentFps.value = fpsMonitor.update(temp, _profile.value)

                    val pwm = when (_profile.value) {
                        "AI" -> calculateAiPwm(temp, prediction.trend, prediction.prediction)
                        "TURBO" -> 255
                        "SILENT" -> if (temp > 45) 40 else 0
                        "MANUAL" -> _manualPwm.value
                        else -> 0
                    }
                    if (bluetoothManager.connectionState.value == BluetoothManager.ConnectionState.CONNECTED) {
                        bluetoothManager.sendCommand("PWM:$pwm")
                    }
                    _fanPercent.value = (pwm * 100 / 255)
                    _fanRpm.value = 1200 + pwm * 10
                    _fanActive.value = pwm > 20
                    updateHistory(temp)

                    logger.log(temp, _currentFps.value, pwm, _fanRpm.value,
                        _trendValue.value, _predictedTemp.value, prediction.alert, _profile.value)
                    delay(200)
                } catch (e: CancellationException) { throw e
                } catch (e: Exception) {
                    e.printStackTrace()
                    _snackbarMessage.emit("Error: ${e.message}")
                    delay(1000)
                }
            }
        }
    }

    private fun simulateTemperature(): Float {
        val load = if (_profile.value == "TURBO") 0.8f else 0.4f
        val delta = (load * 0.3f - 0.1f) + (Math.random().toFloat() - 0.5f) * 0.4f
        var newTemp = _currentTemp.value + delta
        newTemp = newTemp.coerceIn(28f, 75f)
        return newTemp
    }

    private fun calculateAiPwm(temp: Float, trend: Float, prediction: Float): Int {
        val error = temp - 40f
        val derivative = trend * 4f
        val futureError = (prediction - 40f).coerceAtLeast(0f)
        var pwm = 60 + error * 8 + derivative * 3 + futureError * 4
        pwm = pwm.coerceIn(0f, 255f)
        return if (pwm < 20) 0 else pwm.toInt()
    }

    private fun updateHistory(temp: Float) {
        val newList = _tempHistory.value.toMutableList()
        newList.add(temp)
        if (newList.size > 120) newList.removeAt(0)
        _tempHistory.value = newList
    }

    fun startBluetoothScan() {
        viewModelScope.launch {
            if (!bluetoothManager.isEnabled()) {
                _snackbarMessage.emit("Please enable Bluetooth first")
                return@launch
            }
            bluetoothManager.startScan()
        }
    }
    suspend fun connectToDevice(device: BluetoothDevice): Boolean {
        return bluetoothManager.connect(device).also { success ->
            if (success) {
                bluetoothManager.sendCommand("C")
                _snackbarMessage.emit("Connected to ${device.name}")
            } else _snackbarMessage.emit("Connection failed")
        }
    }
    fun disconnectBluetooth() {
        bluetoothManager.disconnect()
        viewModelScope.launch { _snackbarMessage.emit("Disconnected") }
    }
    fun setProfile(profile: String) {
        _profile.value = profile
        viewModelScope.launch { _snackbarMessage.emit("Profile: $profile") }
    }
    fun setManualPwm(value: Int) { _manualPwm.value = value.coerceIn(0, 255) }
    fun setRgb(r: Int, g: Int, b: Int) {
        if (bluetoothManager.connectionState.value == BluetoothManager.ConnectionState.CONNECTED) {
            bluetoothManager.sendCommand("RGB:$r,$g,$b")
        }
    }
    fun exportCsv(): String? = logger.exportCsv().also {
        if (it != null) viewModelScope.launch { _snackbarMessage.emit("CSV saved: $it") }
        else viewModelScope.launch { _snackbarMessage.emit("Failed to export CSV") }
    }
    fun exportExcel(): String? {
        val link = logger.generateGoogleSheetsLink()
        viewModelScope.launch { _snackbarMessage.emit("Open link: $link") }
        return link
    }
    fun clearLogs() { logger.clear(); viewModelScope.launch { _snackbarMessage.emit("Logs cleared") } }
    fun getGoogleSheetsLink(): String = logger.generateGoogleSheetsLink()

    override fun onCleared() {
        backgroundJob?.cancel()
        bluetoothManager.cleanup()
        super.onCleared()
    }
}