package com.ehsan.icooler

import android.bluetooth.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.channels.Channel
import java.io.IOException
import java.util.*

class BluetoothManager(
    private val context: Context,
    private val externalScope: CoroutineScope
) {
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var bluetoothSocket: BluetoothSocket? = null
    private val uuid = UUID.fromString("a1b2c3d4-5678-90ab-cdef-1234567890ab")

    private val _scanResults = MutableStateFlow<List<BluetoothDevice>>(emptyList())
    val scanResults: StateFlow<List<BluetoothDevice>> = _scanResults.asStateFlow()
    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    enum class ConnectionState { DISCONNECTED, SCANNING, CONNECTING, CONNECTED, DISCONNECTING }

    private var currentDevice: BluetoothDevice? = null
    private var reconnectJob: Job? = null
    private var retryCount = 0
    private val maxRetries = 5
    private val responseChannel = Channel<Byte>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                    if (device?.name?.contains("Fangaming") == true) {
                        _scanResults.value = _scanResults.value + device
                    }
                }
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    _connectionState.value = ConnectionState.DISCONNECTED
                    startReconnectWithBackoff()
                }
            }
        }
    }

    init {
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
        }
        context.registerReceiver(receiver, filter)
        externalScope.launch(Dispatchers.IO) { listenForResponses() }
    }

    fun isEnabled(): Boolean = bluetoothAdapter?.isEnabled == true
    fun startScan() {
        if (!isEnabled()) return
        _scanResults.value = emptyList()
        _connectionState.value = ConnectionState.SCANNING
        bluetoothAdapter?.startDiscovery()
    }
    fun stopScan() {
        bluetoothAdapter?.cancelDiscovery()
        if (_connectionState.value == ConnectionState.SCANNING) _connectionState.value = ConnectionState.DISCONNECTED
    }
    suspend fun connect(device: BluetoothDevice): Boolean = withContext(Dispatchers.IO) {
        _connectionState.value = ConnectionState.CONNECTING
        currentDevice = device
        retryCount = 0
        try {
            bluetoothAdapter?.cancelDiscovery()
            bluetoothSocket = device.createRfcommSocketToServiceRecord(uuid)
            withTimeout(10000L) { bluetoothSocket?.connect() }
            _connectionState.value = ConnectionState.CONNECTED
            reconnectJob?.cancel()
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            _connectionState.value = ConnectionState.DISCONNECTED
            return@withContext false
        }
    }
    private fun startReconnectWithBackoff() {
        if (retryCount >= maxRetries) return
        val delayMs = (1000 * Math.pow(2.0, retryCount.toDouble())).toLong()
        retryCount++
        reconnectJob = externalScope.launch {
            delay(delayMs)
            if (_connectionState.value == ConnectionState.DISCONNECTED && currentDevice != null) {
                connect(currentDevice!!)
            }
        }
    }
    fun disconnect() {
        _connectionState.value = ConnectionState.DISCONNECTING
        reconnectJob?.cancel()
        try { bluetoothSocket?.close() } catch (e: IOException) { e.printStackTrace() }
        bluetoothSocket = null
        _connectionState.value = ConnectionState.DISCONNECTED
        currentDevice = null
    }
    suspend fun sendCommand(command: String): Boolean {
        if (_connectionState.value != ConnectionState.CONNECTED) return false
        return withContext(Dispatchers.IO) {
            try {
                val outputStream = bluetoothSocket?.outputStream ?: return@withContext false
                outputStream.write((command + "\n").toByteArray())
                outputStream.flush()
                true
            } catch (e: IOException) { e.printStackTrace(); false }
        }
    }
    private suspend fun listenForResponses() {
        while (true) {
            try {
                val inputStream = bluetoothSocket?.inputStream ?: run { delay(500); continue }
                val byte = inputStream.read()
                if (byte != -1) responseChannel.send(byte.toByte())
            } catch (e: IOException) { delay(500) }
        }
    }
    suspend fun waitForAck(timeoutMs: Long = 500): Boolean {
        return withTimeoutOrNull(timeoutMs) {
            for (byte in responseChannel) { if (byte == 'A'.code.toByte()) return@withTimeoutOrNull true }
            false
        } ?: false
    }
    fun cleanup() {
        context.unregisterReceiver(receiver)
        disconnect()
    }
}