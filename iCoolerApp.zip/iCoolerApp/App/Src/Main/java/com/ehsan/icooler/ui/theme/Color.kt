package com.ehsan.icooler.ui.theme
import androidx.compose.ui.graphics.Color
val BackgroundDark = Color(0xFF0A0A14)
val CardGlass = Color(0x1AFFFFFF)
val CardBorder = Color(0x33FFFFFF)
val TextPrimary = Color.White
val TextSecondary = Color(0xB3FFFFFF)
val AccentBlue = Color(0xFF00B0FF)
val AccentGreen = Color(0xFF00E676)
val AccentOrange = Color(0xFFFF9100)
val AccentRed = Color(0xFFFF3D3D)
val FpsActive = Color(0xFF00E676)
val FpsIdle = Color.White