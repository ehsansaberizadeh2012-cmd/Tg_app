package com.ehsan.icooler
import kotlin.random.Random
class FPSMonitor {
    private var currentFps = 60
    fun update(temp: Float, profile: String): Int {
        val baseFps = if (profile == "TURBO") 120 else 60
        val penalty = ((temp - 40).coerceAtLeast(0f) * 2.2f).toInt()
        currentFps = (baseFps - penalty).coerceIn(30, 120) + Random.nextInt(-1,2)
        return currentFps.coerceIn(30,120)
    }
}