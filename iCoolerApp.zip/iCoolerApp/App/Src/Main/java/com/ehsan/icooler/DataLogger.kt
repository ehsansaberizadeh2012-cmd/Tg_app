package com.ehsan.icooler

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.opencsv.CSVWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.*

data class LogRecord(
    val timestamp: String,
    val tempC: Float,
    val fps: Int,
    val pwm: Int,
    val fanPercent: Int,
    val rpm: Int,
    val trend: Float,
    val prediction: Float,
    val alert: Int,
    val profile: String
)

class DataLogger(private val context: Context, private val maxRecords: Int = 5000) {
    private val records = mutableListOf<LogRecord>()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun log(temp: Float, fps: Int, pwm: Int, rpm: Int, trend: Float, prediction: Float, alert: Int, profile: String) {
        records.add(LogRecord(dateFormat.format(Date()), temp, fps, pwm, (pwm * 100 / 255), rpm, trend, prediction, alert, profile))
        if (records.size > maxRecords) records.removeAt(0)
    }
    fun exportCsv(): String? {
        val filename = "iCooler_${System.currentTimeMillis()}.csv"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) exportUsingMediaStore(filename, "text/csv")
        else exportToLegacyStorage(filename)
    }
    fun generateGoogleSheetsLink(): String = "https://docs.google.com/spreadsheets/d/1ABC123DEF456/edit?usp=sharing"

    private fun exportUsingMediaStore(filename: String, mimeType: String): String? {
        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
        uri?.let {
            resolver.openOutputStream(it)?.use { outputStream ->
                OutputStreamWriter(outputStream).use { writer -> CSVWriter(writer).use { csvWriter -> writeCsv(csvWriter) } }
                return uri.toString()
            }
        }
        return null
    }
    private fun exportToLegacyStorage(filename: String): String? {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!downloadsDir.exists()) downloadsDir.mkdirs()
        val file = File(downloadsDir, filename)
        FileOutputStream(file).use { outputStream ->
            OutputStreamWriter(outputStream).use { writer -> CSVWriter(writer).use { csvWriter -> writeCsv(csvWriter) } }
            return file.absolutePath
        }
    }
    private fun writeCsv(csvWriter: CSVWriter) {
        csvWriter.writeNext(arrayOf("Timestamp","Temp(C)","FPS","PWM","Fan%","RPM","Trend(°C/s)","Prediction(C)","Alert","Profile"))
        records.takeLast(1000).forEach { rec ->
            csvWriter.writeNext(arrayOf(rec.timestamp, rec.tempC.toString(), rec.fps.toString(), rec.pwm.toString(),
                rec.fanPercent.toString(), rec.rpm.toString(), rec.trend.toString(), rec.prediction.toString(),
                rec.alert.toString(), rec.profile))
        }
    }
    fun clear() = records.clear()
    fun getRecent(n: Int) = records.takeLast(n)
    fun size() = records.size
}