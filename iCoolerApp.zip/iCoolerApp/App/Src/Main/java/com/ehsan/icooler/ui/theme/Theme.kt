package com.ehsan.icooler.ui.theme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
private val DarkColorScheme = darkColorScheme(
    primary = AccentBlue, secondary = AccentGreen, tertiary = AccentOrange,
    background = BackgroundDark, surface = CardGlass,
    onPrimary = Color.White, onSecondary = Color.Black,
    onBackground = TextPrimary, onSurface = TextPrimary
)
@Composable
fun ICoolerProTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColorScheme, typography = Typography, content = content)
}