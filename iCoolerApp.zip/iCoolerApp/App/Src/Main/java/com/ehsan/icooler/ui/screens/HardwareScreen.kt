package com.ehsan.icooler.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.ehsan.icooler.BluetoothManager
import com.ehsan.icooler.MainViewModel
import com.ehsan.icooler.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun HardwareScreen(viewModel: MainViewModel, navController: NavController, requestEnableBluetooth: () -> Unit) {
    val bluetoothManager = viewModel.bluetoothManager
    val connectionState by bluetoothManager.connectionState.collectAsState()
    val scanResults by bluetoothManager.scanResults.collectAsState()
    val profile by viewModel.profile.collectAsState()
    val manualPwm by viewModel.manualPwm.collectAsState()
    val fanPercent by viewModel.fanPercent.collectAsState()
    val coroutineScope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("🔧 HARDWARE CONTROL", fontSize = 20.sp, color = Color.White, modifier = Modifier.padding(start = 8.dp))
        }
        Spacer(modifier = Modifier.height(16.dp))
        GlassCard {
            Text("Bluetooth Device", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(8.dp))
            Text(when (connectionState) { BluetoothManager.ConnectionState.CONNECTED -> "Connected to FangamingV1"
                BluetoothManager.ConnectionState.CONNECTING -> "Connecting..."
                BluetoothManager.ConnectionState.SCANNING -> "Scanning..."
                else -> "Disconnected" },
                color = when (connectionState) { BluetoothManager.ConnectionState.CONNECTED -> AccentGreen
                    BluetoothManager.ConnectionState.CONNECTING -> AccentOrange
                    else -> Color.Red })
            Spacer(modifier = Modifier.height(8.dp))
            if (connectionState == BluetoothManager.ConnectionState.DISCONNECTED) {
                Button(onClick = { if (!bluetoothManager.isEnabled()) requestEnableBluetooth() else viewModel.startBluetoothScan() }, modifier = Modifier.fillMaxWidth()) { Text("SCAN FOR DEVICES") }
            } else if (connectionState == BluetoothManager.ConnectionState.SCANNING) {
                Button(onClick = { bluetoothManager.stopScan() }, modifier = Modifier.fillMaxWidth()) { Text("STOP SCAN") }
            } else if (connectionState == BluetoothManager.ConnectionState.CONNECTED) {
                Button(onClick = { viewModel.disconnectBluetooth() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = AccentRed)) { Text("DISCONNECT") }
            }
        }
        if (scanResults.isNotEmpty() && connectionState == BluetoothManager.ConnectionState.SCANNING) {
            Spacer(modifier = Modifier.height(16.dp))
            GlassCard {
                Text("Available Devices", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.height(150.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(scanResults) { device ->
                        Card(modifier = Modifier.fillMaxWidth().height(48.dp), colors = CardDefaults.cardColors(containerColor = CardGlass)) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.CenterStart) {
                                Text("${device.name ?: "Unknown"} (${device.address})", color = Color.White, modifier = Modifier.padding(horizontal = 12.dp))
                            }
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        GlassCard {
            Text("Cooling Profile", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = profile == "AI", onClick = { viewModel.setProfile("AI") }, label = { Text("AI SMART") }, modifier = Modifier.weight(1f))
                FilterChip(selected = profile == "TURBO", onClick = { viewModel.setProfile("TURBO") }, label = { Text("TURBO") }, modifier = Modifier.weight(1f))
                FilterChip(selected = profile == "SILENT", onClick = { viewModel.setProfile("SILENT") }, label = { Text("SILENT") }, modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(8.dp))
            FilterChip(selected = profile == "MANUAL", onClick = { viewModel.setProfile("MANUAL") }, label = { Text("MANUAL PWM") }, modifier = Modifier.fillMaxWidth())
        }
        if (profile == "MANUAL") {
            Spacer(modifier = Modifier.height(16.dp))
            GlassCard {
                Text("PWM Override", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(8.dp))
                Slider(value = manualPwm.toFloat(), onValueChange = { viewModel.setManualPwm(it.toInt()) }, valueRange = 0f..255f, steps = 255,
                    colors = SliderDefaults.colors(thumbColor = AccentBlue, activeTrackColor = AccentBlue))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("0", color = TextSecondary); Text("PWM: $manualPwm / 255", color = AccentBlue, fontSize = 14.sp); Text("255", color = TextSecondary)
                }
                Text("Fan Speed: $fanPercent%", color = Color.White)
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
        GlassCard {
            Text("RGB Fan Lighting", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { viewModel.setRgb(0, 100, 255) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0066CC))) { Text("BLUE") }
                Button(onClick = { viewModel.setRgb(0, 255, 0) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00AA00))) { Text("GREEN") }
                Button(onClick = { viewModel.setRgb(255, 0, 0) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4444))) { Text("RED") }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}