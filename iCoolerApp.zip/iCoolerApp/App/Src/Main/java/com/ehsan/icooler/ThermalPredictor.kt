package com.ehsan.icooler
import kotlin.math.abs
data class PredictionResult(val trend: Float, val prediction: Float, val confidence: Float, val alert: Int, val status: String)
class ThermalPredictor(
    private val alpha: Float = 0.35f,
    private val beta: Float = 0.15f
) {
    private var ema: Float = 32.0f
    private var emaTrend: Float = 0.0f
    private var lastTemp: Float = 32.0f
    private var lastTime: Long = System.currentTimeMillis()
    fun update(currentTemp: Float): PredictionResult {
        val now = System.currentTimeMillis()
        val dt = (now - lastTime) / 1000.0f
        val instantTrend = if (dt > 0.001f) (currentTemp - lastTemp) / dt else 0f
        lastTemp = currentTemp; lastTime = now
        ema = alpha * currentTemp + (1 - alpha) * ema
        emaTrend = beta * instantTrend + (1 - beta) * emaTrend
        val prediction = currentTemp + emaTrend * 10
        val confidence = 1f - (abs(emaTrend) / 2f).coerceIn(0f, 1f)
        val alert = when { currentTemp > 50 || prediction > 50 -> 2; currentTemp > 45 || prediction > 45 -> 1; else -> 0 }
        val status = when (alert) {
            2 -> "CRITICAL – Overheating"
            1 -> "WARNING – Cooling required"
            else -> when { emaTrend > 0.2f -> "Heating rapidly"; emaTrend > 0.05f -> "Warming up"; emaTrend < -0.1f -> "Cooling down"; else -> "Stable" }
        }
        return PredictionResult(emaTrend, prediction, confidence, alert, status)
    }
    fun reset() { ema = 32.0f; emaTrend = 0.0f; lastTemp = 32.0f; lastTime = System.currentTimeMillis() }
}